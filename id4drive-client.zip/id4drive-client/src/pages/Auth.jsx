import { useState, useEffect, useRef } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { sendSmsCode, verifySmsCode, resetRecaptcha } from '../firebase/auth'
import { saveUserProfile, getUserProfile } from '../firebase/db'
import { useTheme } from '../hooks/useTheme'
import { normalizePhone, formatPhone } from '../utils/format'
import './Auth.css'

const TSCS = [
  { id: '8045', name: 'ТСЦ 8045', area: 'Святошинський р-н, вул. Тулузи 1' },
  { id: '8042', name: 'ТСЦ 8042', area: 'Соломʼянський р-н, вул. Героїв Севастополя' },
  { id: '8043', name: 'ТСЦ 8043', area: 'Деснянський р-н, вул. Берковецька' },
]

const EXPERIENCES = [
  { id: 'novice', name: 'Початківець', desc: 'Без досвіду або менше 10 годин' },
  { id: 'basic', name: 'Базовий', desc: 'Закінчена автошкола, потрібно шліфувати' },
  { id: 'licensed', name: 'З правами', desc: 'Є посвідчення, велика перерва' },
]

export default function Auth({ user, profile, onProfileSaved }) {
  const { theme, toggle } = useTheme()
  const nav = useNavigate()

  // step: 'phone' | 'sms' | 'survey'
  const [step, setStep] = useState(user && !profile ? 'survey' : 'phone')

  // phone step
  const [phoneInput, setPhoneInput] = useState('')
  const [phone, setPhone] = useState('')
  const [phoneError, setPhoneError] = useState('')
  const [sending, setSending] = useState(false)

  // sms step
  const [code, setCode] = useState('')
  const [codeError, setCodeError] = useState('')
  const [verifying, setVerifying] = useState(false)
  const [resendTimer, setResendTimer] = useState(45)
  const codeInputRef = useRef(null)

  // survey step
  const [name, setName] = useState('')
  const [studentType, setStudentType] = useState('school')
  const [tscId, setTscId] = useState('8045')
  const [experience, setExperience] = useState('novice')
  const [filmingConsent, setFilmingConsent] = useState(true)
  const [termsAgreed, setTermsAgreed] = useState(false)
  const [savingProfile, setSavingProfile] = useState(false)

  useEffect(() => {
    if (step !== 'sms') return
    if (resendTimer <= 0) return
    const t = setTimeout(() => setResendTimer(s => s - 1), 1000)
    return () => clearTimeout(t)
  }, [step, resendTimer])

  useEffect(() => {
    if (step === 'sms' && codeInputRef.current) {
      codeInputRef.current.focus()
    }
  }, [step])

  // ─── PHONE ───────────────────────────────────────────
  const handleSendCode = async () => {
    setPhoneError('')
    const normalized = normalizePhone('+380' + phoneInput)
    if (!normalized) {
      setPhoneError('Введи коректний номер')
      return
    }
    setSending(true)
    try {
      await sendSmsCode(normalized)
      setPhone(normalized)
      setStep('sms')
      setResendTimer(45)
    } catch (e) {
      console.error(e)
      setPhoneError(e.message || 'Не вдалось надіслати SMS')
      await resetRecaptcha()
    } finally {
      setSending(false)
    }
  }

  // ─── SMS ─────────────────────────────────────────────
  const handleVerifyCode = async () => {
    setCodeError('')
    if (code.length !== 6) {
      setCodeError('Введи 6-значний код')
      return
    }
    setVerifying(true)
    try {
      const u = await verifySmsCode(code)
      // Перевіряємо чи є вже профіль
      const existing = await getUserProfile(u.uid)
      if (existing) {
        // Уже зареєстрований → одразу в кабінет
        nav('/cabinet')
      } else {
        // Нова реєстрація → анкета
        setStep('survey')
      }
    } catch (e) {
      console.error(e)
      setCodeError('Невірний код')
    } finally {
      setVerifying(false)
    }
  }

  const handleResend = async () => {
    if (resendTimer > 0) return
    setCode('')
    setCodeError('')
    try {
      await resetRecaptcha()
      await sendSmsCode(phone)
      setResendTimer(45)
    } catch (e) {
      setCodeError(e.message || 'Помилка повторної відправки')
    }
  }

  // ─── SURVEY ──────────────────────────────────────────
  const handleSaveProfile = async () => {
    if (!name.trim()) {
      alert('Введи імʼя')
      return
    }
    if (!termsAgreed) {
      alert('Потрібно прийняти умови')
      return
    }
    setSavingProfile(true)
    try {
      const uid = user?.uid
      if (!uid) {
        alert('Помилка авторизації')
        nav('/auth')
        return
      }
      const data = {
        name: name.trim(),
        phone: phone || user?.phoneNumber || '',
        studentType,
        filmingConsent,
        termsAccepted: true,
        createdAt: Date.now()
      }
      if (studentType === 'school') data.tscCenter = tscId
      else data.experience = experience

      await saveUserProfile(uid, data)
      if (onProfileSaved) await onProfileSaved()
      nav('/cabinet')
    } catch (e) {
      console.error(e)
      alert('Помилка збереження: ' + e.message)
    } finally {
      setSavingProfile(false)
    }
  }

  // ─── RENDER ──────────────────────────────────────────
  const ThemeBtn = () => (
    <button className="icon-btn" onClick={toggle} aria-label="Тема">
      {theme === 'dark' ? (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
        </svg>
      ) : (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="5"/>
          <line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/>
          <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
          <line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/>
          <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
        </svg>
      )}
    </button>
  )

  return (
    <div className="auth-page">

      {/* PHONE STEP */}
      {step === 'phone' && (
        <div className="fade-up" style={{display:'flex', flexDirection:'column', flex:1}}>
          <header className="auth-header">
            <Link to="/" className="back-btn">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
            </Link>
            <div className="step-indicator">
              <div className="step-dot active"></div>
              <div className="step-dot"></div>
              <div className="step-dot"></div>
            </div>
            <ThemeBtn />
          </header>

          <div className="auth-logo-block">
            <div className="auth-logo-icon">🚗</div>
            <div className="auth-logo-name">ID4Drive</div>
          </div>

          <h1 className="auth-h1">Введи свій <span className="acc">телефон</span></h1>
          <p className="auth-sub">Надішлемо SMS-код для підтвердження. Без паролів і email — лише номер.</p>

          {phoneError && <div className="auth-error">{phoneError}</div>}

          <div className="phone-card">
            <div className="phone-flag">UA</div>
            <div className="phone-code">+380</div>
            <input
              className="phone-input"
              type="tel"
              placeholder="98 922 5442"
              maxLength={13}
              inputMode="numeric"
              value={phoneInput}
              onChange={e => setPhoneInput(e.target.value.replace(/\D/g, '').slice(0, 9))}
              autoFocus
            />
          </div>

          <div id="recaptcha-container"></div>

          <div className="bottom-spacer">
            <button className="btn-primary" onClick={handleSendCode} disabled={sending || phoneInput.length < 9}>
              {sending ? 'Надсилаємо...' : 'Надіслати код →'}
            </button>
          </div>
        </div>
      )}

      {/* SMS STEP */}
      {step === 'sms' && (
        <div className="fade-up" style={{display:'flex', flexDirection:'column', flex:1}}>
          <header className="auth-header">
            <button className="back-btn" onClick={() => { setStep('phone'); resetRecaptcha(); }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
            </button>
            <div className="step-indicator">
              <div className="step-dot done"></div>
              <div className="step-dot active"></div>
              <div className="step-dot"></div>
            </div>
            <ThemeBtn />
          </header>

          <div className="auth-logo-block">
            <div className="auth-logo-icon">📱</div>
            <div className="auth-logo-name">SMS</div>
          </div>

          <h1 className="auth-h1">Введи <span className="acc">код</span> з SMS</h1>
          <p className="auth-sub">
            Відправили 6-значний код на<br/>
            <b style={{color:'var(--text)'}}>{formatPhone(phone)}</b> ·{' '}
            <button className="resend-link" onClick={() => { setStep('phone'); resetRecaptcha(); }}>змінити</button>
          </p>

          {codeError && <div className="auth-error">{codeError}</div>}

          <div className="code-grid" onClick={() => codeInputRef.current?.focus()}>
            {Array.from({length: 6}).map((_, i) => {
              const filled = code.length > i
              const active = code.length === i
              return (
                <div key={i} className={`code-cell ${filled ? 'filled' : ''} ${active ? 'active' : ''}`}>
                  {filled ? code[i] : ''}
                </div>
              )
            })}
          </div>

          <input
            ref={codeInputRef}
            className="code-input-hidden"
            type="tel"
            inputMode="numeric"
            maxLength={6}
            value={code}
            onChange={e => {
              const v = e.target.value.replace(/\D/g, '').slice(0, 6)
              setCode(v)
              if (v.length === 6) {
                // Авто-підтвердження після 6 цифр
                setTimeout(() => handleVerifyCode(), 200)
              }
            }}
            autoFocus
          />

          <div className="timer-row">
            Не отримав код?{' '}
            {resendTimer > 0
              ? <span className="accent">Повторно через 0:{String(resendTimer).padStart(2,'0')}</span>
              : <button className="resend-link" onClick={handleResend}>Надіслати ще раз</button>
            }
          </div>

          <div className="bottom-spacer">
            <button className="btn-primary" onClick={handleVerifyCode} disabled={verifying || code.length !== 6}>
              {verifying ? 'Перевіряємо...' : 'Підтвердити →'}
            </button>
          </div>
        </div>
      )}

      {/* SURVEY STEP */}
      {step === 'survey' && (
        <div className="fade-up" style={{display:'flex', flexDirection:'column', flex:1}}>
          <header className="auth-header">
            <div style={{width:40}}></div>
            <div className="step-indicator">
              <div className="step-dot done"></div>
              <div className="step-dot done"></div>
              <div className="step-dot active"></div>
            </div>
            <ThemeBtn />
          </header>

          <h1 className="auth-h1" style={{marginTop:12}}>Розкажи <span className="acc">про себе</span></h1>
          <p className="auth-sub">Заповни анкету — і одразу зможеш записатись на урок.</p>

          {/* Імʼя */}
          <div className="field">
            <div className="field-label">Імʼя та прізвище</div>
            <input
              className="text-input"
              type="text"
              placeholder="Олексій Петренко"
              value={name}
              onChange={e => setName(e.target.value)}
            />
          </div>

          {/* Тип навчання */}
          <div className="section-title">Тип навчання</div>
          <div className="warning-card">
            <div className="warning-ico">⚠</div>
            <div className="warning-text">
              Вибір робиться <b>один раз</b>. Змінити тип потім не можна. Якщо обираєш Автошколу — після 40 уроків автоматично відкриються Приватні.
            </div>
          </div>
          <div className="choice-grid">
            <div className={`tile-pick ${studentType === 'school' ? 'selected' : ''}`} onClick={() => setStudentType('school')}>
              <div className="ico ico-school">🎓</div>
              <div className="tile-title">Автошкола</div>
              <div className="tile-desc">Повний курс з ТСЦ, 40 годин, документи</div>
            </div>
            <div className={`tile-pick ${studentType === 'private' ? 'selected' : ''}`} onClick={() => setStudentType('private')}>
              <div className="ico ico-private">🚙</div>
              <div className="tile-title">Приватний</div>
              <div className="tile-desc">Індивідуально, гнучкий графік</div>
            </div>
          </div>

          {/* ТСЦ для автошколи */}
          {studentType === 'school' && (
            <>
              <div className="section-title">Який ТСЦ обираєш</div>
              <div className="select-list">
                {TSCS.map(t => (
                  <div
                    key={t.id}
                    className={`select-item ${tscId === t.id ? 'selected' : ''}`}
                    onClick={() => setTscId(t.id)}
                  >
                    <div className="select-radio"></div>
                    <div className="select-info">
                      <div className="select-title">{t.name}</div>
                      <div className="select-sub">{t.area}</div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Досвід для приватного */}
          {studentType === 'private' && (
            <>
              <div className="section-title">Досвід водіння</div>
              <div className="select-list">
                {EXPERIENCES.map(e => (
                  <div
                    key={e.id}
                    className={`select-item ${experience === e.id ? 'selected' : ''}`}
                    onClick={() => setExperience(e.id)}
                  >
                    <div className="select-radio"></div>
                    <div className="select-info">
                      <div className="select-title">{e.name}</div>
                      <div className="select-sub">{e.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Зйомка */}
          <div className="section-title">Дозвіл на зйомку</div>
          <div className="toggle-row">
            <div className="toggle-ico">📹</div>
            <div className="toggle-info">
              <div className="toggle-title">Зйомка для соцмереж</div>
              <div className="toggle-desc">Інструктор може зняти короткий відеоролик з твоїм уроком для Instagram/TikTok</div>
            </div>
            <button className={`switch ${filmingConsent ? 'on' : ''}`} onClick={() => setFilmingConsent(c => !c)}>
              <div className="switch-knob"></div>
            </button>
          </div>

          {/* Умови */}
          <div className="section-title">Умови надання послуг</div>
          <button className={`terms-survey-btn ${termsAgreed ? 'agreed' : ''}`} onClick={() => setTermsAgreed(a => !a)}>
            <div className="terms-survey-ico">
              {termsAgreed ? '✓' : '📄'}
            </div>
            <div className="terms-survey-text">
              <div className="lbl">{termsAgreed ? 'Прийнято' : 'Обовʼязково'}</div>
              <div>{termsAgreed ? 'Умови прочитано та підтверджено' : 'Прочитати та прийняти умови'}</div>
            </div>
            <span style={{color: termsAgreed ? '#7ed957' : '#f87171', fontSize:'18px'}}>{termsAgreed ? '✓' : '›'}</span>
          </button>

          <button
            className="btn-primary"
            disabled={!termsAgreed || !name.trim() || savingProfile}
            onClick={handleSaveProfile}
            style={{marginTop:8}}
          >
            {savingProfile ? 'Зберігаємо...' : 'Завершити реєстрацію'}
          </button>
        </div>
      )}

    </div>
  )
}
