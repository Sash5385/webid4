# SETUP-WIN.ps1
# Швидкий старт проекту на Windows
# Запуск: PowerShell в папці проекту → .\SETUP-WIN.ps1

Write-Host "ID4Drive Client - Setup" -ForegroundColor Cyan
Write-Host ""

# Перевірка Node.js
$node = node -v 2>$null
if (-not $node) {
    Write-Host "Node.js не встановлено. Завантаж з https://nodejs.org/" -ForegroundColor Red
    exit 1
}
Write-Host "Node.js: $node" -ForegroundColor Green

# Перевірка .env
if (-not (Test-Path .env)) {
    Write-Host ""
    Write-Host "Файл .env не знайдено. Створюю з .env.example..." -ForegroundColor Yellow
    Copy-Item .env.example .env
    Write-Host ".env створено. ВІДКРИЙ ЙОГО І ПІДСТАВ КЛЮЧІ З Firebase Console" -ForegroundColor Yellow
    Write-Host "Firebase Console -> Project Settings -> Your apps -> Config" -ForegroundColor White
}

# npm install
Write-Host ""
Write-Host "Встановлюю залежності..." -ForegroundColor Cyan
npm install

# Перевірка SW
$sw = Get-Content public\firebase-messaging-sw.js -Raw
if ($sw -match "ПІДСТАВИТИ") {
    Write-Host ""
    Write-Host "УВАГА: в public\firebase-messaging-sw.js залишились заглушки ПІДСТАВИТИ" -ForegroundColor Yellow
    Write-Host "Підстав ключі apiKey, messagingSenderId, appId з Firebase Console" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "ГОТОВО. Запусти: npm run dev" -ForegroundColor Green
Write-Host "Відкриється http://localhost:5173" -ForegroundColor White
