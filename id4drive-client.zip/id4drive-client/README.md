# ID4Drive — Сайт учня

Веб-додаток для учнів автошколи. Лендінг + особистий кабінет з записом на уроки.

**Тех. стек:** React 18, Vite 5, Firebase 10 (Auth + Realtime DB + FCM), React Router 6, PWA.

---

## 🚀 ШВИДКИЙ СТАРТ

### 1. Встанови залежності
```bash
npm install
```

### 2. Налаштуй Firebase

#### A) Створи Web App (якщо ще немає)
1. Зайди в Firebase Console → Project `id4drive-booking-44182`
2. Project Settings → General → Your apps
3. Натисни `</>` (Add web app)
4. Назви `id4drive-client`, без Hosting — натисни Register

#### B) Скопіюй конфіг
1. Project Settings → Your apps → знайди `id4drive-client` → SDK setup → Config
2. Скопіюй значення `apiKey`, `messagingSenderId`, `appId`

#### C) Зроби `.env`
```bash
cp .env.example .env
```
Підстав значення з пункту B.

#### D) VAPID key для Push
1. Project Settings → Cloud Messaging → Web configuration
2. Generate key pair → скопіюй у `.env` як `VITE_FIREBASE_VAPID_KEY`

#### E) Підстав ключі в `public/firebase-messaging-sw.js`
Service worker не бачить .env, треба захардкодити вручну.
Замінити `ПІДСТАВИТИ` на реальні значення apiKey/messagingSenderId/appId.

### 3. Налаштуй Security Rules
1. Firebase Console → Realtime Database → Rules
2. Вставити вміст файлу `firebase-rules.json`
3. Publish

### 4. Перевір Phone Auth
- Authentication → Sign-in method → Phone — Enable
- SMS region: Україна (UA) — увімкнути

### 5. Запусти dev
```bash
npm run dev
```
Відкриється http://localhost:5173

---

## 📁 СТРУКТУРА

```
id4drive-client/
├── public/
│   ├── favicon.svg
│   └── firebase-messaging-sw.js     # FCM background push
├── src/
│   ├── firebase/
│   │   ├── config.js                # Firebase init
│   │   ├── auth.js                  # SMS вхід/вихід
│   │   ├── db.js                    # Realtime DB CRUD
│   │   └── push.js                  # FCM токени
│   ├── hooks/
│   │   ├── useTheme.js              # dark/light
│   │   └── useBookings.js           # підписка на букінги
│   ├── utils/
│   │   ├── date.js                  # форматування дат, календар
│   │   └── format.js                # телефон, ініціали
│   ├── pages/
│   │   ├── Landing.jsx + .css       # Головна сторінка
│   │   ├── Auth.jsx + .css          # 3-крокова авторизація
│   │   ├── Cabinet.jsx + .css       # Обгортка з bottom nav
│   │   └── cabinet/
│   │       ├── BookTab.jsx + .css   # Запис на урок
│   │       ├── BookingsTab.jsx      # Мої записи
│   │       ├── ProgressTab.jsx      # Прогрес 40 годин
│   │       └── ProfileTab.jsx       # Профіль + тема + вихід
│   ├── styles/
│   │   ├── tokens.css               # CSS змінні (теми)
│   │   └── global.css               # Базові стилі
│   ├── App.jsx                      # Routes + auth check
│   └── main.jsx                     # Entry point
├── .env.example
├── .gitignore
├── firebase-rules.json              # Security rules для DB
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

---

## 🎨 ДИЗАЙН-СИСТЕМА

- **Темна тема (default):** фон #1c1d21, акцент #ff5a3c
- **Світла тема:** фон #f0f1f5, акцент той самий
- Neumorphism: подвійні shadow (inset+outer)
- Перемикання в кабінеті → Профіль → Тема

---

## 🔥 БІЗНЕС-ЛОГІКА

1. **Авторизація:** SMS (Firebase Phone Auth) → анкета (один раз)
2. **Тип учня обирається 1 раз:**
   - `school` — автошкола, ТСЦ, ліміт 40 годин
   - `private` — приватний, досвід
3. **Після 40 годин school** автоматично відкривається запис на private
4. **Цілі уроку** — з 10-го confirmed уроку (до 3)
5. **Зайнятий слот** → діалог "стати в чергу"
6. **Силуети в слотах** — золоті, показують позицію в черзі (до 3 видно, далі +N)

---

## 📦 DEPLOY

### Firebase Hosting (рекомендовано)
```bash
npm install -g firebase-tools
firebase login
firebase use id4drive-booking-44182
firebase init hosting        # public=dist, SPA=Yes, GitHub=No
npm run build
firebase deploy --only hosting
```

### Custom domain
Firebase Console → Hosting → Add custom domain → `id4drive.pro`

---

## 📱 PWA

- Іконки 192/512 згенеруй на https://realfavicongenerator.net
- Поклади в `public/icon-192.png` і `public/icon-512.png`
- Service worker уже зареєстрований через vite-plugin-pwa
- FCM background push працює через `firebase-messaging-sw.js`

---

## ⚠️ ЩО ЩЕ ТРЕБА ЗРОБИТИ

- [ ] Згенерувати PWA іконки 192x512
- [ ] Підставити всі ключі в `.env` + `firebase-messaging-sw.js`
- [ ] Опублікувати firebase-rules.json
- [ ] Створити окремий admin uid у `/admins/{uid}: true` (для змін цін/слотів)
- [ ] Деплой
- [ ] Привʼязати домен id4drive.pro
